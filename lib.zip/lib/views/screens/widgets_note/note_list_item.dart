import 'package:flutter/material.dart';
import 'package:practice_2/utils/app_constants.dart';

class NoteListItem extends StatefulWidget {
  int index;
  String text;
  final Function() delete;
  final Function() edit;
  NoteListItem({
    required this.index,
    required this.edit,
    required this.delete,
    required this.text,
    super.key,
  });

  @override
  State<NoteListItem> createState() => _NoteListItemState();
}

class _NoteListItemState extends State<NoteListItem> {
  @override
  Widget build(BuildContext context) {
    return Container(
      // height: 80,

      padding: const EdgeInsets.all(15),
      margin: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.blue[300],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Text(
                widget.text,
                style: TextStyle(fontSize: AppConstants.fontSizeText),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: widget.edit,
                    icon: const Icon(
                      Icons.edit,
                      color: Colors.white,
                    ),
                  ),
                  IconButton(
                    onPressed: widget.delete,
                    icon: const Icon(
                      Icons.delete,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              Text(
                AppConstants.listNote[widget.index].dateTime
                    .toString()
                    .substring(0, 16),
                style: const TextStyle(color: Colors.indigo),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:practice_2/utils/app_constants.dart';
import 'package:practice_2/views/widgets/custom_drawer.dart';

class SettingsScreen extends StatefulWidget {
  final ValueChanged<bool> onThemeChanged;
  const SettingsScreen({
    super.key,
    required this.onThemeChanged,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  var textController = TextEditingController();
  int valueItemLanguage = 0;
  String? labelSizeText;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Sozlamalar",
          style: TextStyle(fontSize: AppConstants.fontSizeText),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              AppConstants.language,
              style: TextStyle(fontSize: AppConstants.fontSizeText),
            ),
          )
        ],
      ),
      drawer: CustomDrawer(onThemeChanged: widget.onThemeChanged),
      body: Container(
        decoration: BoxDecoration(
            image: AppConstants.backgroundImage.isNotEmpty
                ? DecorationImage(
                    image: NetworkImage(AppConstants.backgroundImage))
                : null),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 20),
              SwitchListTile(
                value: AppConstants.themeMode == ThemeMode.dark,
                onChanged: widget.onThemeChanged,
                title: Text(
                  "Tungi holat",
                  style: TextStyle(fontSize: AppConstants.fontSizeText),
                ),
              ),
              const Divider(height: 30),
              const SizedBox(height: 20),
              TextField(
                controller: textController,
                decoration: const InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  AppConstants.backgroundImage = textController.text;
                  setState(() {});
                },
                child: Text(
                  "Submit",
                  style: TextStyle(fontSize: AppConstants.fontSizeText),
                ),
              ),
              const SizedBox(height: 20),
              const Divider(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Select language",
                    style: TextStyle(fontSize: AppConstants.fontSizeText),
                  ),
                  DropdownButton(
                      value: valueItemLanguage,
                      items: [
                        DropdownMenuItem(
                          value: 0,
                          child: Text(
                            "uz",
                            style:
                                TextStyle(fontSize: AppConstants.fontSizeText),
                          ),
                        ),
                        DropdownMenuItem(
                          value: 1,
                          child: Text(
                            "ru",
                            style:
                                TextStyle(fontSize: AppConstants.fontSizeText),
                          ),
                        ),
                        DropdownMenuItem(
                          value: 2,
                          child: Text(
                            "eng",
                            style:
                                TextStyle(fontSize: AppConstants.fontSizeText),
                          ),
                        ),
                      ],
                      onChanged: (value) {
                        if (value == 0) {
                          AppConstants.language = "uz";
                          valueItemLanguage = 0;
                        } else if (value == 1) {
                          AppConstants.language = "ru";
                          valueItemLanguage = 1;
                        } else {
                          AppConstants.language = "eng";
                          valueItemLanguage = 2;
                        }
                        setState(() {});
                      }),
                ],
              ),
              const Divider(height: 30),
              Text(
                "Select size text:",
                style: TextStyle(fontSize: AppConstants.fontSizeText),
              ),
              Slider(
                min: 15,
                max: 40,
                label: '${AppConstants.fontSizeText - 15}',
                divisions: 5,
                value: AppConstants.fontSizeText,
                onChanged: (value) {
                  AppConstants.fontSizeText = value;
                  setState(() {});
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

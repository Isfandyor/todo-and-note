import 'package:flutter/material.dart';
import 'package:practice_2/utils/app_constants.dart';
import 'package:practice_2/views/widgets/custom_drawer.dart';
import 'package:practice_2/views/widgets/tab_first.dart';
import 'package:practice_2/views/widgets/tab_second.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<bool> onThemeChanged;
  const HomeScreen({
    super.key,
    required this.onThemeChanged,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "Bosh Sahifa",
            style: TextStyle(fontSize: AppConstants.fontSizeText),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                AppConstants.language,
                style: TextStyle(fontSize: AppConstants.fontSizeText),
              ),
            )
          ],
        ),
        drawer: CustomDrawer(
          onThemeChanged: widget.onThemeChanged,
        ),
        body: Column(
          children: [
            const TabBar(
                labelPadding: EdgeInsets.all(20),
                indicatorWeight: 5,
                indicatorSize: TabBarIndicatorSize.tab,
                tabs: [
                  Text(
                    "TO DO",
                  ),
                  Text(
                    "NOTES",
                  ),
                ]),
            Expanded(
              child: TabBarView(children: [
                TabFirst(),
                TabSecond(),
              ]),
            )
          ],
        ),
      ),
    );
  }
}

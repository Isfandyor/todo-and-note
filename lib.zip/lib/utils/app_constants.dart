import 'package:flutter/material.dart';
import 'package:practice_2/models/note.dart';
import 'package:practice_2/models/todo.dart';

class AppConstants {
  static ThemeMode themeMode = ThemeMode.light;
  static String backgroundImage = "";
  static String language = "uz";
  static double fontSizeText = 15;
  static String? passwordApp;
  static String passoword = "1234";
  static List<Note> listNote = [
    Note(text: "Bugun yuguraman"),
    Note(text: "Kitob o'qish"),
    Note(text: "Soat tuzatish"),
    Note(text: "Uhlash"),
    Note(text: "Suv ichish"),
    Note(text: "Ovqatlanish"),
  ];

  static List<Todo> listTodo = [
    Todo(text: "Bugun yuguraman", isDone: false),
    Todo(text: "Kitob o'qish", isDone: false),
    Todo(text: "Soat tuzatish", isDone: false),
    Todo(text: "Uhlash", isDone: false),
    Todo(text: "Suv ichish", isDone: false),
    Todo(text: "Ovqatlanish", isDone: false),
  ];
}

class Todo {
  String text;
  bool isDone;
  Todo({
    required this.text,
    required this.isDone,
  });
}

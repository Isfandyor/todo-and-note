class Note {
  String text;
  DateTime dateTime = DateTime.now();
  Note({
    required this.text,
  });
}
